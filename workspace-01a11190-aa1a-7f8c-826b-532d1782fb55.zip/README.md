# HomeLuxe Real Estate

A pixel-faithful recreation of the HomeLuxe real-estate landing page as a single,
self-contained `index.html` (all photography AI-generated and embedded as data URIs,
Inter font embedded as a base64 woff2 — no external assets required).

## Sections

- Trust top bar + sticky-style header with nav
- Hero ("Find Your Perfect Home") with generated villa photography
- Buy / Rent / Sell property search card
- Feature highlights (perfect home, expert agents, trusted & secure, best deals)
- Featured property listings (Beverly Hills, Austin, Miami, San Diego)
- "Get Maximum Value" seller CTA with home-value estimate card
- "Why Choose Us" + newsletter strip
- Full footer

## Usage

Open `index.html` in any browser, or serve the folder statically:

```bash
python3 -m http.server 8080
```

Source photos (AI-generated) live in `images/`.
